</main>
<footer class="footer">Doctor Appointment System &copy; <?= date('Y') ?> | College Mini Project</footer>
<script src="<?= BASE_URL ?>/js/script.js"></script>
</body>
</html>
