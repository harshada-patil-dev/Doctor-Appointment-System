<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $department = (int)($_POST['department_id'] ?? 0);
    $specialization = trim($_POST['specialization'] ?? '');
    $fee = (float)($_POST['fee'] ?? 0);

    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL)
        && $phone && $password && $department && $specialization) {

        try {
            $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $check->execute([$email]);

            if ($check->fetch()) {
                $message = "Email already registered!";
            } else {
                $pdo->beginTransaction();

                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare(
                    "INSERT INTO users (name, email, password, phone, role)
                     VALUES (?, ?, ?, ?, 'doctor')"
                );

                $stmt->execute([
                    $name,
                    $email,
                    $hashedPassword,
                    $phone
                ]);

                $userId = $pdo->lastInsertId();

                $stmt = $pdo->prepare(
                    "INSERT INTO doctors
                    (user_id, department_id, specialization, fee)
                    VALUES (?, ?, ?, ?)"
                );

                $stmt->execute([
                    $userId,
                    $department,
                    $specialization,
                    $fee
                ]);

                $pdo->commit();

                $message = "Doctor Registration Successful!";
            }

        } catch (PDOException $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $message = "Error: " . $e->getMessage();
        }

    } else {
        $message = "Please fill all fields correctly.";
    }
}

$departments = $pdo->query(
    "SELECT id, name FROM departments ORDER BY name"
)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Registration - MediCare</title>

    <style>
        body {
            font-family: Arial;
            background: #f1f6f9;
            margin: 0;
            padding: 40px;
        }

        .container {
            width: 450px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px #ccc;
        }

        h2 {
            text-align: center;
            color: #117c98;
        }

        input, select {
            width: 100%;
            padding: 12px;
            margin: 10px 0 18px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 13px;
            background: #117c98;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            text-align: center;
            color: green;
            margin: 15px 0;
        }

        a {
            color: #117c98;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Doctor Registration</h2>

    <?php if ($message): ?>
        <p class="message">
            <?= htmlspecialchars($message) ?>
        </p>
    <?php endif; ?>

    <form method="POST">

        <label>Doctor Full Name</label>
        <input type="text" name="name" required>

        <label>Email Address</label>
        <input type="email" name="email" required>

        <label>Phone Number</label>
        <input type="text" name="phone"
               pattern="[0-9]{10}" maxlength="10" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <label>Department</label>
        <select name="department_id" required>
            <option value="">Select Department</option>

            <?php foreach ($departments as $dept): ?>
                <option value="<?= $dept['id'] ?>">
                    <?= htmlspecialchars($dept['name']) ?>
                </option>
            <?php endforeach; ?>

        </select>

        <label>Specialization</label>
        <input type="text" name="specialization" required>

        <label>Consultation Fee (₹)</label>
        <input type="number" name="fee" min="0" step="0.01" required>

        <button type="submit">Register as Doctor</button>

    </form>

    <p style="text-align:center;">
        Already registered? <a href="login.php">Doctor Login</a>
    </p>

</div>

</body>
</html>