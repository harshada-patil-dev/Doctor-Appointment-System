<?php
require_once __DIR__ . '/../config.php';
require_role('patient');
$pageTitle = 'My Appointments';
$pid = $_SESSION['user']['id'];

// Cancel appointment (only own, only Pending/Confirmed)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel'])) {
    $pdo->prepare('UPDATE appointments SET status = "Cancelled"
                   WHERE id = ? AND patient_id = ? AND status IN ("Pending","Confirmed")')
        ->execute([(int)$_POST['id'], $pid]);
    flash('Appointment cancelled.');
    redirect('patient/dashboard.php');
}

$stmt = $pdo->prepare('SELECT a.*, du.name AS doctor_name, dep.name AS department, d.fee
                       FROM appointments a
                       JOIN doctors d ON d.id = a.doctor_id
                       JOIN users du ON du.id = d.user_id
                       JOIN departments dep ON dep.id = d.department_id
                       WHERE a.patient_id = ?
                       ORDER BY a.appointment_date DESC, a.appointment_time DESC');
$stmt->execute([$pid]);
$rows = $stmt->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h2>My Appointments</h2>
<p><a class="btn" href="book.php">+ Book New Appointment</a></p>
<div class="table-wrap">
<table>
  <thead><tr><th>#</th><th>Doctor</th><th>Department</th><th>Date</th><th>Time</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead>
  <tbody>
  <?php if (!$rows): ?><tr><td colspan="8" class="empty">You have no appointments yet.</td></tr><?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= $r['id'] ?></td>
      <td>Dr. <?= e($r['doctor_name']) ?></td>
      <td><?= e($r['department']) ?></td>
      <td><?= date('d M Y', strtotime($r['appointment_date'])) ?></td>
      <td><?= date('h:i A', strtotime($r['appointment_time'])) ?></td>
      <td><?= e($r['reason']) ?></td>
      <td><span class="badge badge-<?= strtolower($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td>
        <?php if (in_array($r['status'], ['Pending', 'Confirmed'])): ?>
          <form method="post" class="inline-form" data-confirm="Cancel this appointment?">
            <input type="hidden" name="id" value="<?= $r['id'] ?>">
            <button class="btn btn-sm btn-danger" name="cancel" type="submit">Cancel</button>
          </form>
        <?php else: ?>-<?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
