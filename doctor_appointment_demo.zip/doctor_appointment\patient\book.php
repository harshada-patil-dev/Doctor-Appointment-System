<?php
require_once __DIR__ . '/../config.php';
require_role('patient');
$pageTitle = 'Book Appointment';
$errors = [];

$departments = $pdo->query('SELECT * FROM departments ORDER BY name')->fetchAll();
$doctors = $pdo->query('SELECT d.id, d.department_id, d.specialization, d.fee, u.name
                        FROM doctors d JOIN users u ON u.id = d.user_id ORDER BY u.name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctorId = (int)($_POST['doctor_id'] ?? 0);
    $date     = $_POST['date'] ?? '';
    $time     = $_POST['time'] ?? '';
    $reason   = trim($_POST['reason'] ?? '');

    $exists = $pdo->prepare('SELECT COUNT(*) FROM doctors WHERE id = ?');
    $exists->execute([$doctorId]);

    if (!$exists->fetchColumn())                         $errors[] = 'Please select a valid doctor.';
    if (!$date || $date < date('Y-m-d'))                  $errors[] = 'Please select today or a future date.';
    if (!in_array($time, time_slots()))                   $errors[] = 'Please select a valid time slot.';
    if ($reason === '')                                   $errors[] = 'Please enter a reason for the visit.';

    if (!$errors) {
        // Prevent double booking of the same doctor/date/time
        $busy = $pdo->prepare('SELECT COUNT(*) FROM appointments
                               WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ? AND status != "Cancelled"');
        $busy->execute([$doctorId, $date, $time]);
        if ($busy->fetchColumn()) {
            $errors[] = 'That slot is already booked. Please choose another time.';
        } else {
            $pdo->prepare('INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason)
                           VALUES (?,?,?,?,?)')
                ->execute([$_SESSION['user']['id'], $doctorId, $date, $time, $reason]);
            flash('Appointment booked! Waiting for confirmation.');
            redirect('patient/dashboard.php');
        }
    }
}
include __DIR__ . '/../includes/header.php';
?>
<div class="form-box">
  <h2>Book an Appointment</h2>
  <?php foreach ($errors as $err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endforeach; ?>
  <?php if (!$doctors): ?>
    <p class="empty">No doctors are available yet. Please check back later.</p>
  <?php else: ?>
  <form method="post" data-validate>
    <label>Department</label>
    <select id="department" name="department_id" required>
      <option value="">-- Select department --</option>
      <?php foreach ($departments as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['name']) ?></option><?php endforeach; ?>
    </select>

    <label>Doctor</label>
    <select name="doctor_id" id="doctor" required>
      <option value="">-- Select doctor --</option>
      <?php foreach ($doctors as $d): ?>
        <?php $doctorName = preg_replace('/^Dr\.?\s*/i', '', $d['name']); ?>
        <option value="<?= $d['id'] ?>" data-dept="<?= $d['department_id'] ?>">
          Dr. <?= e($doctorName) ?> (<?= e($d['specialization']) ?>) - &#8377;<?= number_format($d['fee']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <label>Date</label>
    <input type="date" name="date" id="date" required>

    <label>Time Slot</label>
    <select name="time" required>
      <option value="">-- Select time --</option>
      <?php foreach (time_slots() as $t): ?><option value="<?= $t ?>"><?= date('h:i A', strtotime($t)) ?></option><?php endforeach; ?>
    </select>

    <label>Reason for Visit</label>
    <textarea name="reason" rows="3" required></textarea>

    <button class="btn" type="submit">Book Appointment</button>
  </form>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
