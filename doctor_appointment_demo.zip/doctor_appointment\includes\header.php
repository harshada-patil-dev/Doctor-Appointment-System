<?php $u = $_SESSION['user'] ?? null; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle ?? 'Doctor Appointment System') ?></title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<nav class="navbar">
  <a class="brand" href="<?= BASE_URL ?>/index.php">+ MediCare</a>
  <div class="nav-links">
    <?php if (!$u): ?>
      <a href="<?= BASE_URL ?>/index.php">Home</a>
      <a href="<?= BASE_URL ?>/login.php">Login</a>
      <a href="<?= BASE_URL ?>/register.php">Register</a>
    <?php elseif ($u['role'] === 'admin'): ?>
      <a href="<?= BASE_URL ?>/admin/dashboard.php">Dashboard</a>
      <a href="<?= BASE_URL ?>/admin/departments.php">Departments</a>
      <a href="<?= BASE_URL ?>/admin/doctors.php">Doctors</a>
      <a href="<?= BASE_URL ?>/admin/appointments.php">Appointments</a>
    <?php elseif ($u['role'] === 'doctor'): ?>
      <a href="<?= BASE_URL ?>/doctor/dashboard.php">My Appointments</a>
    <?php else: ?>
      <a href="<?= BASE_URL ?>/patient/dashboard.php">My Appointments</a>
      <a href="<?= BASE_URL ?>/patient/book.php">Book Appointment</a>
    <?php endif; ?>
    <?php if ($u): ?>
      <span class="user-tag"><?= e($u['name']) ?> (<?= e($u['role']) ?>)</span>
      <a class="btn-link" href="<?= BASE_URL ?>/logout.php">Logout</a>
    <?php endif; ?>
  </div>
</nav>
<main class="container">
<?php if (!empty($_SESSION['flash'])): $f = $_SESSION['flash']; unset($_SESSION['flash']); ?>
  <div class="alert alert-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
<?php endif; ?>
