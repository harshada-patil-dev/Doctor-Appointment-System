document.addEventListener('DOMContentLoaded', function() {

    // 1. Confirm before delete / cancel actions
    document.querySelectorAll('form[data-confirm]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            if (!confirm(form.dataset.confirm)) e.preventDefault();
        });
    });

    // 2. Auto-hide flash messages after 4 seconds
    document.querySelectorAll('.alert').forEach(function(a) {
        setTimeout(function() {
            a.style.transition = 'opacity .5s';
            a.style.opacity = '0';
            setTimeout(function() { a.remove(); }, 500);
        }, 4000);
    });

    // 3. Booking page: filter doctors by selected department
    var dept = document.getElementById('department');
    var doctor = document.getElementById('doctor');
    if (dept && doctor) {
        var allOptions = Array.from(doctor.querySelectorAll('option[data-dept]'));
        var placeholder = doctor.querySelector('option:not([data-dept])');

        function refreshDoctorOptions() {
            doctor.value = '';
            var hasDoctors = false;
            allOptions.forEach(function(opt) {
                var show = dept.value === '' || opt.dataset.dept === dept.value;
                opt.hidden = !show;
                opt.disabled = !show;
                hasDoctors = hasDoctors || show;
            });
            placeholder.textContent = dept.value === '' ?
                '-- Select department first --' :
                hasDoctors ? '-- Select doctor --' : '-- No doctors in this department --';
            doctor.disabled = dept.value === '' || !hasDoctors;
        }

        dept.addEventListener('change', refreshDoctorOptions);
        refreshDoctorOptions();
    }

    // 4. Booking page: block past dates
    var dateInput = document.getElementById('date');
    if (dateInput) {
        var t = new Date();
        dateInput.min = t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
    }

    // 5. Simple client-side check: password match on registration
    var regForm = document.querySelector('form[data-validate]');
    if (regForm) {
        var pw = regForm.querySelector('input[name="password"]');
        var cf = regForm.querySelector('input[name="confirm"]');
        if (pw && cf) {
            regForm.addEventListener('submit', function(e) {
                if (pw.value !== cf.value) {
                    e.preventDefault();
                    alert('Passwords do not match.');
                }
            });
        }
    }
});