<?php
require_once __DIR__ . '/../config.php';
require_role('admin');
handle_status_update($pdo);
$pageTitle = 'All Appointments';

$filter = $_GET['status'] ?? '';
$sql = 'SELECT a.*, p.name AS patient_name, p.phone AS patient_phone,
               du.name AS doctor_name, dep.name AS department
        FROM appointments a
        JOIN users p ON p.id = a.patient_id
        JOIN doctors d ON d.id = a.doctor_id
        JOIN users du ON du.id = d.user_id
        JOIN departments dep ON dep.id = d.department_id';
$params = [];
if (in_array($filter, STATUSES)) { $sql .= ' WHERE a.status = ?'; $params[] = $filter; }
$sql .= ' ORDER BY a.appointment_date DESC, a.appointment_time DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
$showPatient = true; $showDoctor = true;
include __DIR__ . '/../includes/header.php';
?>
<h2>All Appointments</h2>
<form method="get" class="form-row">
  <select name="status" onchange="this.form.submit()">
    <option value="">All statuses</option>
    <?php foreach (STATUSES as $s): ?><option <?= $s === $filter ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
  </select>
</form>
<?php include __DIR__ . '/../includes/appointment_table.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
