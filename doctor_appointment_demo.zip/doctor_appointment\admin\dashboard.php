<?php
require_once __DIR__ . '/../config.php';
require_role('admin');
$pageTitle = 'Admin Dashboard';

$count = fn($sql) => (int)$pdo->query($sql)->fetchColumn();
$stats = [
    'Doctors'      => $count('SELECT COUNT(*) FROM doctors'),
    'Patients'     => $count('SELECT COUNT(*) FROM users WHERE role="patient"'),
    'Departments'  => $count('SELECT COUNT(*) FROM departments'),
    'Appointments' => $count('SELECT COUNT(*) FROM appointments'),
    'Pending'      => $count('SELECT COUNT(*) FROM appointments WHERE status="Pending"'),
    'Completed'    => $count('SELECT COUNT(*) FROM appointments WHERE status="Completed"'),
];
include __DIR__ . '/../includes/header.php';
?>
<h2>Admin Dashboard</h2>
<div class="grid stats">
  <?php foreach ($stats as $label => $n): ?>
    <div class="card stat"><span class="num"><?= $n ?></span><span><?= e($label) ?></span></div>
  <?php endforeach; ?>
</div>
<p><a class="btn" href="doctors.php">Manage Doctors</a>
   <a class="btn btn-outline" href="departments.php">Manage Departments</a>
   <a class="btn btn-outline" href="appointments.php">View Appointments</a></p>
<?php include __DIR__ . '/../includes/footer.php'; ?>
