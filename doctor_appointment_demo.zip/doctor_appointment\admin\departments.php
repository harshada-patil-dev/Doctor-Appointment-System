<?php
require_once __DIR__ . '/../config.php';
require_role('admin');
$pageTitle = 'Manage Departments';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        if ($name === '') {
            flash('Department name is required.', 'error');
        } else {
            try {
                $pdo->prepare('INSERT INTO departments (name, description) VALUES (?,?)')->execute([$name, $desc]);
                flash('Department added.');
            } catch (PDOException $ex) {
                flash('Department already exists.', 'error');
            }
        }
    } elseif (isset($_POST['delete'])) {
        try {
            $pdo->prepare('DELETE FROM departments WHERE id = ?')->execute([(int)$_POST['id']]);
            flash('Department deleted.');
        } catch (PDOException $ex) {
            flash('Cannot delete: doctors are assigned to this department.', 'error');
        }
    }
    redirect('admin/departments.php');
}
$departments = $pdo->query('SELECT * FROM departments ORDER BY name')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h2>Departments</h2>
<form method="post" class="card form-row">
  <input type="text" name="name" placeholder="Department name" required>
  <input type="text" name="description" placeholder="Short description">
  <button class="btn" name="add" type="submit">Add Department</button>
</form>

<div class="table-wrap">
<table>
  <thead><tr><th>#</th><th>Name</th><th>Description</th><th>Action</th></tr></thead>
  <tbody>
  <?php foreach ($departments as $d): ?>
    <tr>
      <td><?= $d['id'] ?></td><td><?= e($d['name']) ?></td><td><?= e($d['description']) ?></td>
      <td>
        <form method="post" class="inline-form" data-confirm="Delete this department?">
          <input type="hidden" name="id" value="<?= $d['id'] ?>">
          <button class="btn btn-sm btn-danger" name="delete" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
