<?php
require_once __DIR__ . '/../config.php';
require_role('admin');
$pageTitle = 'Manage Doctors';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $pass  = $_POST['password'] ?? '';
        $dept  = (int)($_POST['department_id'] ?? 0);
        $spec  = trim($_POST['specialization'] ?? '');
        $fee   = (float)($_POST['fee'] ?? 0);

        $chk = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $chk->execute([$email]);

        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6 || !$dept) {
            flash('Please fill all fields correctly (password min 6 chars).', 'error');
        } elseif ($chk->fetch()) {
            flash('Email already exists.', 'error');
        } else {
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO users (name, email, password, phone, role) VALUES (?,?,?,?, "doctor")')
                ->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT), $phone]);
            $uid = $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO doctors (user_id, department_id, specialization, fee) VALUES (?,?,?,?)')
                ->execute([$uid, $dept, $spec, $fee]);
            $pdo->commit();
            flash('Doctor added successfully.');
        }
    } elseif (isset($_POST['delete'])) {
        // deleting the user cascades to doctor + appointments
        $pdo->prepare('DELETE FROM users WHERE id = ? AND role = "doctor"')->execute([(int)$_POST['user_id']]);
        flash('Doctor deleted.');
    }
    redirect('admin/doctors.php');
}

$departments = $pdo->query('SELECT * FROM departments ORDER BY name')->fetchAll();
$doctors = $pdo->query('SELECT d.*, u.name, u.email, u.phone, dep.name AS department
                        FROM doctors d JOIN users u ON u.id = d.user_id
                        JOIN departments dep ON dep.id = d.department_id
                        ORDER BY u.name')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h2>Doctors</h2>
<form method="post" class="card" data-validate>
  <h3>Add New Doctor</h3>
  <div class="form-grid">
    <input type="text" name="name" placeholder="Doctor name" required>
    <input type="email" name="email" placeholder="Login email" required>
    <input type="password" name="password" placeholder="Password (min 6)" minlength="6" required>
    <input type="text" name="phone" placeholder="Phone">
    <select name="department_id" required>
      <option value="">-- Department --</option>
      <?php foreach ($departments as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['name']) ?></option><?php endforeach; ?>
    </select>
    <input type="text" name="specialization" placeholder="Specialization">
    <input type="number" name="fee" placeholder="Consultation fee" min="0" step="0.01">
  </div>
  <button class="btn" name="add" type="submit">Add Doctor</button>
</form>

<div class="table-wrap">
<table>
  <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Department</th><th>Specialization</th><th>Fee</th><th>Action</th></tr></thead>
  <tbody>
  <?php if (!$doctors): ?><tr><td colspan="7" class="empty">No doctors yet.</td></tr><?php endif; ?>
  <?php foreach ($doctors as $d): ?>
    <tr>
      <td><?= $d['id'] ?></td>
      <td>Dr. <?= e($d['name']) ?></td><td><?= e($d['email']) ?></td>
      <td><?= e($d['department']) ?></td><td><?= e($d['specialization']) ?></td>
      <td>&#8377;<?= number_format($d['fee'], 2) ?></td>
      <td>
        <form method="post" class="inline-form" data-confirm="Delete this doctor and all their appointments?">
          <input type="hidden" name="user_id" value="<?= $d['user_id'] ?>">
          <button class="btn btn-sm btn-danger" name="delete" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
