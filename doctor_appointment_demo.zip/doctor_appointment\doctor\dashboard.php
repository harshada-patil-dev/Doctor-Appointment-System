<?php
require_once __DIR__ . '/../config.php';
require_role('doctor');
$pageTitle = 'Doctor Dashboard';

$d = $pdo->prepare('SELECT id FROM doctors WHERE user_id = ?');
$d->execute([$_SESSION['user']['id']]);
$doctorId = (int)$d->fetchColumn();

handle_status_update($pdo, $doctorId);

$stmt = $pdo->prepare('SELECT a.*, p.name AS patient_name, p.phone AS patient_phone
                       FROM appointments a JOIN users p ON p.id = a.patient_id
                       WHERE a.doctor_id = ?
                       ORDER BY a.appointment_date DESC, a.appointment_time DESC');
$stmt->execute([$doctorId]);
$rows = $stmt->fetchAll();

$today = date('Y-m-d');
$todayCount = count(array_filter($rows, fn($r) => $r['appointment_date'] === $today && $r['status'] !== 'Cancelled'));
$pending    = count(array_filter($rows, fn($r) => $r['status'] === 'Pending'));
$showPatient = true; $showDoctor = false;
include __DIR__ . '/../includes/header.php';
?>
<h2>Welcome, Dr. <?= e($_SESSION['user']['name']) ?></h2>
<div class="grid stats">
  <div class="card stat"><span class="num"><?= $todayCount ?></span><span>Today's Appointments</span></div>
  <div class="card stat"><span class="num"><?= $pending ?></span><span>Pending</span></div>
  <div class="card stat"><span class="num"><?= count($rows) ?></span><span>Total</span></div>
</div>
<h3>My Appointments</h3>
<?php include __DIR__ . '/../includes/appointment_table.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
