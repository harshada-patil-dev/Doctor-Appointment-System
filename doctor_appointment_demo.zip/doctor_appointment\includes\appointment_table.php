<?php
// Expects: $rows, $showPatient (bool), $showDoctor (bool)
?>
<div class="table-wrap">
<table>
  <thead>
    <tr>
      <th>#</th>
      <?php if ($showPatient): ?><th>Patient</th><?php endif; ?>
      <?php if ($showDoctor): ?><th>Doctor</th><?php endif; ?>
      <th>Date</th><th>Time</th><th>Reason</th><th>Status</th><th>Update Status</th>
    </tr>
  </thead>
  <tbody>
  <?php if (!$rows): ?>
    <tr><td colspan="8" class="empty">No appointments found.</td></tr>
  <?php endif; ?>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= $r['id'] ?></td>
      <?php if ($showPatient): ?><td><?= e($r['patient_name']) ?><br><small><?= e($r['patient_phone']) ?></small></td><?php endif; ?>
      <?php if ($showDoctor): ?><td>Dr. <?= e($r['doctor_name']) ?><br><small><?= e($r['department']) ?></small></td><?php endif; ?>
      <td><?= date('d M Y', strtotime($r['appointment_date'])) ?></td>
      <td><?= date('h:i A', strtotime($r['appointment_time'])) ?></td>
      <td><?= e($r['reason']) ?></td>
      <td><span class="badge badge-<?= strtolower($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <td>
        <form method="post" class="inline-form">
          <input type="hidden" name="appointment_id" value="<?= $r['id'] ?>">
          <select name="status">
            <?php foreach (STATUSES as $s): ?>
              <option <?= $s === $r['status'] ? 'selected' : '' ?>><?= $s ?></option>
            <?php endforeach; ?>
          </select>
          <button type="submit" name="update_status" class="btn btn-sm">Save</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
